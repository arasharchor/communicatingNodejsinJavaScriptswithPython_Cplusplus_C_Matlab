## 0.0.3
* fixed buffering in `PythonShell.receive`, fixing [#1](https://github.com/extrabacon/python-shell/issues/1)

## 0.0.2
* improved documentation

## 0.0.1
* initial version
* independent module moved from [extrabacon/pyspreadsheet](https://github.com/extrabacon/pyspreadsheet)

