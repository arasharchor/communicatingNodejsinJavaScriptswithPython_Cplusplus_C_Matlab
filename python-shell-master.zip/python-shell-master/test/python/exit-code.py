import sys
exit_code = int(sys.argv[1]) if len(sys.argv) > 1 else 0
sys.exit(exit_code)
