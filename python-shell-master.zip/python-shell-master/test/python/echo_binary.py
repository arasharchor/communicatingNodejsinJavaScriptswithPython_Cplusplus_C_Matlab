import sys

# simple binary echo script
sys.stdout.write(sys.stdin.read())
