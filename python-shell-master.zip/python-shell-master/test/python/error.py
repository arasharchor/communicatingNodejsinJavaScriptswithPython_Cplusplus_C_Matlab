# simple error script

def divide_by_zero():
  print 1/0

divide_by_zero()
