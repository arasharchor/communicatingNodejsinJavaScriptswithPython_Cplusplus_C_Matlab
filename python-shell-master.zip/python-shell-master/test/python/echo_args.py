import sys

# simple argument echo script
for v in sys.argv[1:]:
  print v
