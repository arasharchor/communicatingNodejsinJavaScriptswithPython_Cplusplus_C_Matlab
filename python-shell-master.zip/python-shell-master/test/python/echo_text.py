import sys, json

# simple JSON echo script
for line in sys.stdin:
  print line[:-1]
